<?php get_header(); ?>

<section class="section container">
	<div class="row">
		<div class="col-12 text-center pt-5" style="color: #e53e3e; font-size: 16px; font-weight: 700;">По вашему запросу ничего не найдено</div>
	</div> 
</section>

<?php get_footer(); ?>