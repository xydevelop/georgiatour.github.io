<?php get_header(); ?>

<section class="section">
  <div>Контент в процессе наполнения</div>
</section>

<?php get_footer(); ?>